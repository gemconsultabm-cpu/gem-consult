#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/com.labelpack.studio"
rm -rf "$DEST"; mkdir -p "$(dirname "$DEST")"
cp -R "$DIR/com.labelpack.studio" "$DEST"
for v in 9 10 11 12 13; do defaults write com.adobe.CSXS.$v PlayerDebugMode 1; done
echo ""
echo "Panneau installé. Redémarrez Illustrator puis ouvrez : Fenêtre > Extensions > Label Pack Studio"
