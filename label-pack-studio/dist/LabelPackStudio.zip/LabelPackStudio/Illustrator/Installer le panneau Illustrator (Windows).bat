@echo off
title Installation du panneau Label Pack Studio pour Illustrator
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.labelpack.studio"
if exist "%DEST%" rmdir /S /Q "%DEST%"
xcopy /E /I /Y /Q "%~dp0com.labelpack.studio" "%DEST%" >nul
for %%v in (9 10 11 12 13) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
echo.
echo Panneau installe. Redemarrez Illustrator puis ouvrez :
echo     Fenetre ^> Extensions ^> Label Pack Studio
echo.
pause
