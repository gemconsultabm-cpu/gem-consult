@echo off
setlocal
title Installation de Label Pack Studio
set "SRC=%~dp0"
if not exist "%SRC%LabelPackStudio.html" goto pas_extrait
set "DEST=%LOCALAPPDATA%\LabelPackStudio"
echo.
echo  Installation de Label Pack Studio dans :
echo    %DEST%
echo.
robocopy "%SRC%." "%DEST%" /E /XD Illustrator /R:1 /W:1 /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 goto erreur_copie
if not exist "%DEST%\LabelPackStudio.html" goto erreur_copie
echo  [OK] Fichiers copies.

rem Navigateur pour le mode application (chemin lu dans le registre Windows)
set "BROWSER="
for %%K in (HKLM HKCU) do if not defined BROWSER for /f "tokens=*" %%L in ('reg query "%%K\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" /ve 2^>nul ^| find "REG_SZ"') do set "LINE=%%L"
if defined LINE call set "BROWSER=%%LINE:*REG_SZ=%%"
if not defined BROWSER for %%K in (HKLM HKCU) do if not defined LINE2 for /f "tokens=*" %%L in ('reg query "%%K\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" /ve 2^>nul ^| find "REG_SZ"') do set "LINE2=%%L"
if not defined BROWSER if defined LINE2 call set "BROWSER=%%LINE2:*REG_SZ=%%"
if defined BROWSER for /f "tokens=*" %%B in ("%BROWSER%") do set "BROWSER=%%~B"
set "TGT=%BROWSER%"
set "ARGS=--app=file:///%DEST:\=/%/LabelPackStudio.html"
if not defined BROWSER set "TGT=%DEST%\LabelPackStudio.html"
if not defined BROWSER set "ARGS="
if not exist "%TGT%" set "TGT=%DEST%\LabelPackStudio.html"
if not exist "%TGT%" set "ARGS="
set "ICO=%DEST%\lib\icone.ico"

rem Raccourcis Bureau et menu Demarrer (PowerShell si disponible, sinon lanceur de secours)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; foreach($d in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){ $s=$w.CreateShortcut((Join-Path $d 'Label Pack Studio.lnk')); $s.TargetPath=$env:TGT; $s.Arguments=$env:ARGS; $s.WorkingDirectory=$env:DEST; $s.IconLocation=$env:ICO; $s.Description='Label Pack Studio'; $s.Save() }" >nul 2>&1
if errorlevel 1 goto raccourci_secours
echo  [OK] Raccourcis "Label Pack Studio" crees sur le Bureau et dans le menu Demarrer.
goto lancer

:raccourci_secours
set "DESK=%USERPROFILE%\Desktop"
if defined OneDrive if exist "%OneDrive%\Desktop" set "DESK=%OneDrive%\Desktop"
> "%DESK%\Label Pack Studio.cmd" echo @call "%DEST%\Ouvrir Label Pack Studio.cmd"
echo  [OK] Lanceur "Label Pack Studio" cree sur le Bureau.

:lancer
echo.
echo  Installation terminee. Ouverture de Label Pack Studio...
call "%DEST%\Ouvrir Label Pack Studio.cmd"
echo.
pause
exit /b 0

:pas_extrait
echo.
echo  ERREUR : ce fichier est lance depuis l'interieur du ZIP.
echo  1. Fermez cette fenetre.
echo  2. Clic droit sur LabelPackStudio.zip, puis "Extraire tout...".
echo  3. Ouvrez le dossier extrait et relancez "1 - Installer sur ce PC (Windows)".
echo.
pause
exit /b 1

:erreur_copie
echo.
echo  ERREUR : copie impossible vers %DEST%
echo  Solution immediate : dans le dossier extrait, double-cliquez sur LabelPackStudio.html
echo  (l'application s'ouvre dans votre navigateur, sans installation).
echo.
pause
exit /b 1
