@echo off
setlocal
rem Ouvre Label Pack Studio en fenetre d'application (Edge, sinon Chrome, sinon navigateur par defaut).
set "HTML=%~dp0LabelPackStudio.html"
if exist "%HTML%" goto ouvrir
echo.
echo  Fichier introuvable : "%HTML%"
echo  Decompressez d'abord le fichier ZIP : clic droit sur le ZIP, puis "Extraire tout".
echo.
pause
exit /b 1
:ouvrir
set "URL=file:///%HTML:\=/%"
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" >nul 2>&1 && (start "" msedge --app="%URL%" & exit /b 0)
reg query "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" >nul 2>&1 && (start "" msedge --app="%URL%" & exit /b 0)
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" >nul 2>&1 && (start "" chrome --app="%URL%" & exit /b 0)
reg query "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" >nul 2>&1 && (start "" chrome --app="%URL%" & exit /b 0)
start "" "%HTML%"
