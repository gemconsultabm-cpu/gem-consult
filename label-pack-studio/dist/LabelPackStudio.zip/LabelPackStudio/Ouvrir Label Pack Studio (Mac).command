#!/bin/bash
# Ouvre Label Pack Studio dans une fenêtre d'application (Chrome ou Edge), sinon dans le navigateur par défaut.
DIR="$(cd "$(dirname "$0")" && pwd)"
HTML="$DIR/LabelPackStudio.html"
URL="file://$(python3 -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1]))' "$HTML" 2>/dev/null || echo "$HTML")"
if [ -d "/Applications/Google Chrome.app" ]; then open -na "Google Chrome" --args --app="$URL"
elif [ -d "/Applications/Microsoft Edge.app" ]; then open -na "Microsoft Edge" --args --app="$URL"
else open "$HTML"; fi
