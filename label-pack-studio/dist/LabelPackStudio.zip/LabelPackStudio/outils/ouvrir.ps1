# Ouvre Label Pack Studio dans une fenêtre d'application (Edge ou Chrome), sans barre d'adresse.
$html = Join-Path (Split-Path -Parent $PSScriptRoot) 'LabelPackStudio.html'
$url = ([System.Uri]$html).AbsoluteUri
$browser = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe", "$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe") | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if ($browser) { Start-Process -FilePath $browser -ArgumentList "--app=$url" } else { Start-Process $html }
