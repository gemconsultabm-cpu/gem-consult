# Installe Label Pack Studio pour l'utilisateur courant (aucun droit administrateur requis)
# et crée les raccourcis sur le Bureau et dans le menu Démarrer.
$ErrorActionPreference = 'Stop'
$src = Split-Path -Parent $PSScriptRoot
$dest = Join-Path $env:LOCALAPPDATA 'LabelPackStudio'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Get-ChildItem -Path $src -Force | Where-Object { $_.Name -ne 'Illustrator' } | ForEach-Object { Copy-Item -Path $_.FullName -Destination $dest -Recurse -Force }
$html = Join-Path $dest 'LabelPackStudio.html'
$url = ([System.Uri]$html).AbsoluteUri
$browser = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe", "$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe") | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
$ws = New-Object -ComObject WScript.Shell
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'))) {
  $lnk = $ws.CreateShortcut((Join-Path $dir 'Label Pack Studio.lnk'))
  if ($browser) { $lnk.TargetPath = $browser; $lnk.Arguments = "--app=$url" } else { $lnk.TargetPath = $html }
  $lnk.WorkingDirectory = $dest
  $lnk.IconLocation = (Join-Path $dest 'lib\icone.ico')
  $lnk.Description = 'Label Pack Studio'
  $lnk.Save()
}
Write-Host ''
Write-Host 'Label Pack Studio est installe.' -ForegroundColor Green
Write-Host 'Raccourcis crees : Bureau et menu Demarrer > Label Pack Studio.'
