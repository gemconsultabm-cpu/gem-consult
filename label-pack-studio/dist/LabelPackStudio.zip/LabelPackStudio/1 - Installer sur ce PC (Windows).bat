@echo off
title Installation de Label Pack Studio
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0outils\installer.ps1"
if errorlevel 1 (echo. & echo L'installation a echoue. Decompressez d'abord le dossier ZIP, puis relancez ce fichier.)
echo.
pause
